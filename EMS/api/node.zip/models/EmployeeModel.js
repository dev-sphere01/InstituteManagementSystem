const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const employeeSchema = new Schema({
    FirstName: {
        type: String,
        required: true
    },
    LastName: {
        type: String,
    },
    PersonalEmail: {
        type: String,
        required: true,
        match: [/^([a-zA-Z0-9_\-.+]+)@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,})$/, 'Please fill a valid email address']
    },
    WorkEmail: {
        type: String,
        match: [/^([a-zA-Z0-9_\-.+]+)@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,})$/, 'Please fill a valid email address']
    },
    PhoneNumber: {
        type: String,
    },
    Address: {
        type: String,
    },
    EmergencyContact: {
        type: String,
    },
    EmergencyContactNumber: {
        type: String,
    },
    DateOfBirth: {
        type: Date,
    },
    Gender: {
        type: String,
    },
    DateOfJoining: {
        type: Date,
    },
    OBStatus: {
        type: Number,
    },
    IsActive: {
        type: Number,
    },
    ProfilePicture: {
        type: String
    }
});

const Employee = mongoose.model('Employee', employeeSchema);

module.exports = Employee;

//This is the schema for the Employee collection in the database