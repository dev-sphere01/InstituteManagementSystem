const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const salaryStructureSchema = new Schema({
    PositionID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Position',
        required: true
    },
    BasicSalary: {
        type: Number
    },
    HRA: {
        type: Number
    },
    DA: {
        type: Number
    },
    OtherAllowances: {
        type: Number
    },
    GrossSalary: {
        type: Number
    },
    ProvidentFund: {
        type: Number
    },
    ProfessionalTax: {
        type: Number
    },
    IncomeTax: {
        type: Number
    },
    OtherDeductions: {
        type: Number
    },
    TotalDeductions: {
        type: Number
    },
    NetSalary: {
        type: Number
    }
});

const SalaryStructure = mongoose.model('SalaryStructure', salaryStructureSchema);

module.exports = SalaryStructure;