const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const leaveSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    LeaveType: {
        type: String
    },
    LeaveReason: {
        type: String
    },
    IsApproved: {
        type: Boolean,
        required: true
    },
    StartDate: {
        type: Date
    },
    EndDate: {
        type: Date
    },
    CreatedAt: {
        type: Date,
        default: Date.now
    }
});

const Leave = mongoose.model('Leave', leaveSchema);

module.exports = Leave;

//This is the schema for the Leave collection in the database