const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const empdeptposSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    DepartmentID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Department',
        required: true
    },
    PositionID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Position',
        required: true
    }
});

const EmpDeptPos = mongoose.model('EmpDeptPos', empdeptposSchema);

module.exports = EmpDeptPos;

//This is the schema for the Employee Department Position collection in the database    