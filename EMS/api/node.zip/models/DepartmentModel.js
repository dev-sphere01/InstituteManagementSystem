const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const departmentSchema = new Schema({
    deptName: {
        type: String,
        required: true
    },
});

const Department = mongoose.model('Department', departmentSchema);

module.exports = Department;

//This is the schema for the Department collection in the database