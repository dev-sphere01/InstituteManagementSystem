const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const empProfDetailSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    PreviousCompany: {
        type: String
    },
    PreviousPosition: {
        type: String
    },
    PreviousExperience: {
        type: Number
    },
    PreviousExperienceCertificate: {
        type: String
    },
});

const EmpProfDetail = mongoose.model('EmpProfDetail', empProfDetailSchema);

module.exports = EmpProfDetail;

//This is the schema for the Employee Profile Details collection in the database

