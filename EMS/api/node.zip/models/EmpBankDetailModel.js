const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const empbankdetailSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    BankName: {
        type: String,
        required: true
    },
    AccountNumber: {
        type: String,
        required: true
    },
    IFSCCode: {
        type: String,
        required: true
    },
    BranchName: {
        type: String,
        required: true
    },
    CancelledCheque: {
        type: String,
        required: true
    }
});

const EmpBankDetail = mongoose.model('EmpBankDetail', empbankdetailSchema);

module.exports = EmpBankDetail;

//This is the schema for the Employee Bank Details collection in the database
