const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const empacaddetailSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    Degree: {
        type: String
    },
    Institution: {
        type: String
    },
    YearOfPassing: {
        type: String
    },
    Grade: {
        type: String
    }
});

const EmpAcadDetail = mongoose.model('EmpAcadDetail', empacaddetailSchema);

module.exports = EmpAcadDetail;

//This is the schema for the Employee Academic Details collection in the database