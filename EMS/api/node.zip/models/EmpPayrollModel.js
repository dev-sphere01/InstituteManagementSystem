const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const empPayrollSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    BasicSalary: {
        type: Number
    },
    HRA: {
        type: Number
    },
    DA: {
        type: Number
    },
    OtherAllowances: {
        type: Number
    },
    GrossSalary: {
        type: Number
    },
    ProvidentFund: {
        type: Number
    },
    ProfessionalTax: {
        type: Number
    },
    IncomeTax: {
        type: Number
    },
    OtherDeductions: {
        type: Number
    },
    TotalDeductions: {
        type: Number
    },
    NetSalary: {
        type: Number
    },
    EffectiveFrom: {
        type: Date,
        required: true
    }
});

const EmpPayroll = mongoose.model('EmpPayroll', empPayrollSchema);

module.exports = EmpPayroll;
