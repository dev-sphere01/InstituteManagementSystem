const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const positionSchema = new Schema({
    DeptID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Department',
        required: true
    },
    PositionName: {
        type: String,
        required: true
    }
});

const Position = mongoose.model('Position', positionSchema);

module.exports = Position;

//This is the schema for the Position collection in the database