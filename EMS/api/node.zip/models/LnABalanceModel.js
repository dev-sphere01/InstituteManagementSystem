const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const lnaBalanceSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    Month: {
        type: String,
        required: true // e.g., "January"
    },
    Year: {
        type: Number,
        required: true
    },
    OpeningBalance: {
        type: Number
    },
    ClosingBalance: {
        type: Number
    },
    AmountRecovered: {
        type: Number
    }
});

const LnABalance = mongoose.model('LnABalance', lnaBalanceSchema);

module.exports = LnABalance;
