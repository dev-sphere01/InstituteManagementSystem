const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const attendanceSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    Date: {
        type: Date,
    },
    CheckInTime: {
        type: Date,
    },
    CheckOutTime: {
        type: Date,
    },
    TotalHours: {
        type: Number,
    }

});

const Attendance = mongoose.model('Attendance', attendanceSchema);

module.exports = Attendance;

//This is the schema for the attendance collection in the database