const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const monthlyPayrollTransactionSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    Month:{
        type: String
    },
    Year:{
        type: Number
    },
    BasicSalary: {
        type: Number
    },
    HRA: {
        type: Number
    },
    DA: {
        type: Number
    },
    OtherAllowances: {
        type: Number
    },
    Deductions: {
        type: Number
    },
    NetPay: {
        type: Number
    },
    TransactionDate: {
        type: Date,
        required: true,
        default: Date.now
    }
});

const MonthlyPayrollTransaction = mongoose.model('MonthlyPayrollTransaction', monthlyPayrollTransactionSchema);

module.exports = MonthlyPayrollTransaction;
