const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const empcredSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    UserName: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        required: true
    }
});

const EmpCred = mongoose.model('EmpCred', empcredSchema);

module.exports = EmpCred;

//This is the schema for the EmpCred collection in the database
