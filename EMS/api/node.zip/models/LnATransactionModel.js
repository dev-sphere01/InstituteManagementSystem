const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const lnATransactionSchema = new Schema({
    LnAID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'LnA',
        required: true
    },
    TransactionDate: {
        type: Date,
        required: true
    },
    Amount: {
        type: Number,
        required: true
    },
    TransactionType: {
        type: String,
        required: true
    },
    Description: {
        type: String
    }
});

const LnATransaction = mongoose.model('LnATransaction', lnATransactionSchema);

module.exports = LnATransaction;
