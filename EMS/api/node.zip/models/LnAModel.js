const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const lnaSchema = new Schema({
    EmpID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true
    },
    LoanAmount: {
        type: Number
    },
    Period: {
        type: Number // in months
    },
    InterestRate: {
        type: Number,
        default: 0.0 // annual interest rate
    },
    MonthlyInstallment: {
        type: Number
    },
    StartDate: {
        type: Date
    }
});

const LnA = mongoose.model('LnA', lnaSchema);

module.exports = LnA;
