const departmentController = require('../controllers/Masters/DepartmentController');
const express = require('express');
const router = express.Router();

// Create a new department
router.post('/create', departmentController.CreateDepartment);
// Get all departments
router.get('/get', departmentController.GetDepartments);
// Get a department by ID
router.get('/get/:id', departmentController.GetDepartment);
// Update a department by ID
router.put('/update/:id', departmentController.UpdateDepartment);
// Delete a department by ID
router.delete('/delete/:id', departmentController.DeleteDepartment);

module.exports = router;
