const employeeController = require('../controllers/Employee/EmployeeController');

const express = require('express');
const router = express.Router();

router.post('/create', employeeController.CreateEmployee);
router.get('/get', employeeController.GetEmployee);
router.put('/update/:id', employeeController.UpdateEmployee);
router.delete('/delete/:id', employeeController.DeleteEmployee);

module.exports = router;
