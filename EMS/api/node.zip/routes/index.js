const express = require('express');

const employeeRoutes = require('./EmployeeRoutes');
const departmentRoutes = require('./DepartmentRoutes');
const positionRoutes = require('./PositionRoutes');

const router = express.Router();

router.use('/employees', employeeRoutes);
router.use('/departments', departmentRoutes);
router.use('/positions', positionRoutes);

module.exports = router;
