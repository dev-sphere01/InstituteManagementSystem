const express = require('express');
const router = express.Router();
const positionController = require('../controllers/Masters/PositionController');

// GET all positions
router.get('/', positionController.getPositions);

// GET position by ID
router.get('/:id', positionController.getPosition);

// CREATE new position
router.post('/', positionController.createPosition);

// UPDATE position by ID
router.put('/:id', positionController.updatePosition);

// DELETE position by ID
router.delete('/:id', positionController.deletePosition);

module.exports = router;
