const EmpAcadDetail = require('../../models/EmpAcadDetailModel');

// Get all EmpAcadDetails
exports.getEmpAcadDetails = async (req, res) => {
  try {
    const empAcadDetails = await EmpAcadDetail.find();
    res.json(empAcadDetails);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get a single EmpAcadDetail by ID
exports.getEmpAcadDetail = async (req, res) => {
  try {
    const empAcadDetail = await EmpAcadDetail.findById(req.params.id);
    if (!empAcadDetail) {
      return res.status(404).json({ message: 'EmpAcadDetail not found' });
    }
    res.json(empAcadDetail);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create a new EmpAcadDetail
exports.createEmpAcadDetail = async (req, res) => {
  const empAcadDetail = new EmpAcadDetail(req.body);
  try {
    const newEmpAcadDetail = await empAcadDetail.save();
    res.status(201).json(newEmpAcadDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Update an EmpAcadDetail by ID
exports.updateEmpAcadDetail = async (req, res) => {
  try {
    const updatedEmpAcadDetail = await EmpAcadDetail.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedEmpAcadDetail) {
      return res.status(404).json({ message: 'EmpAcadDetail not found' });
    }
    res.json(updatedEmpAcadDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Delete an EmpAcadDetail by ID
exports.deleteEmpAcadDetail = async (req, res) => {
  try {
    const empAcadDetail = await EmpAcadDetail.findByIdAndDelete(req.params.id);
    if (!empAcadDetail) {
      return res.status(404).json({ message: 'EmpAcadDetail not found' });
    }
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
