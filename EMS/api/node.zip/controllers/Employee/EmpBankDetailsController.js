const EmpBankDetail = require('../models/EmpBankDetail');

// Get all EmpBankDetails
exports.getEmpBankDetails = async (req, res) => {
  try {
    const empBankDetails = await EmpBankDetail.find();
    res.json(empBankDetails);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get a single EmpBankDetail by ID
exports.getEmpBankDetail = async (req, res) => {
  try {
    const empBankDetail = await EmpBankDetail.findById(req.params.id);
    if (!empBankDetail) {
      return res.status(404).json({ message: 'EmpBankDetail not found' });
    }
    res.json(empBankDetail);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create a new EmpBankDetail
exports.createEmpBankDetail = async (req, res) => {
  const empBankDetail = new EmpBankDetail(req.body);
  try {
    const newEmpBankDetail = await empBankDetail.save();
    res.status(201).json(newEmpBankDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Update an EmpBankDetail by ID
exports.updateEmpBankDetail = async (req, res) => {
  try {
    const updatedEmpBankDetail = await EmpBankDetail.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedEmpBankDetail) {
      return res.status(404).json({ message: 'EmpBankDetail not found' });
    }
    res.json(updatedEmpBankDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Delete an EmpBankDetail by ID
exports.deleteEmpBankDetail = async (req, res) => {
  try {
    const empBankDetail = await EmpBankDetail.findByIdAndDelete(req.params.id);
    if (!empBankDetail) {
      return res.status(404).json({ message: 'EmpBankDetail not found' });
    }
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
