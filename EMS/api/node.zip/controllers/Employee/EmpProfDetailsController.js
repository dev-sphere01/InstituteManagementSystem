const EmpProfDetail = require('../../models/EmpProfDetailModel');

// Get all EmpProfDetails
exports.getEmpProfDetails = async (req, res) => {
  try {
    const empProfDetails = await EmpProfDetail.find();
    res.json(empProfDetails);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get a single EmpProfDetail by ID
exports.getEmpProfDetail = async (req, res) => {
  try {
    const empProfDetail = await EmpProfDetail.findById(req.params.id);
    if (!empProfDetail) {
      return res.status(404).json({ message: 'EmpProfDetail not found' });
    }
    res.json(empProfDetail);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create a new EmpProfDetail
exports.createEmpProfDetail = async (req, res) => {
  const empProfDetail = new EmpProfDetail(req.body);
  try {
    const newEmpProfDetail = await empProfDetail.save();
    res.status(201).json(newEmpProfDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Update an EmpProfDetail by ID
exports.updateEmpProfDetail = async (req, res) => {
  try {
    const updatedEmpProfDetail = await EmpProfDetail.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedEmpProfDetail) {
      return res.status(404).json({ message: 'EmpProfDetail not found' });
    }
    res.json(updatedEmpProfDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Delete an EmpProfDetail by ID
exports.deleteEmpProfDetail = async (req, res) => {
  try {
    const empProfDetail = await EmpProfDetail.findByIdAndDelete(req.params.id);
    if (!empProfDetail) {
      return res.status(404).json({ message: 'EmpProfDetail not found' });
    }
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
