const Employee = require('../../models/EmployeeModel');

const EmpDeptPos = require('../../models/EmpDeptPosModel');
const EmpCred = require('../../models/EmpCredModel');
const Department = require('../../models/DepartmentModel');

// Simple password generator
function generatePassword(length = 8) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
    let password = '';
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
}

exports.CreateEmployee = async (req, res, next) => {
    try {
        if (!req.body) {
            return res.status(400).json({ message: 'Employee data is null.' });
        }

        // 1. Create Employee
        const employeeData = {
            FirstName: req.body.FirstName,
            LastName: req.body.LastName,
            PersonalEmail: req.body.PersonalEmail,
            WorkEmail: req.body.WorkEmail,
            PhoneNumber: req.body.PhoneNumber,
            Address: req.body.Address,
            EmergencyContact: req.body.EmergencyContact,
            EmergencyContactNumber: req.body.EmergencyContactNumber,
            DateOfBirth: req.body.DateOfBirth,
            Gender: req.body.Gender,
            DateOfJoining: req.body.DateOfJoining,
            OBStatus: req.body.OBStatus,
            IsActive: req.body.IsActive,
            ProfilePicture: req.body.ProfilePicture
        };
        const employee = new Employee(employeeData);
        await employee.save();

        // 2. Create EmpDeptPos
        const empDeptPos = new EmpDeptPos({
            EmpID: employee._id,
            DepartmentID: req.body.DepartmentID,
            PositionID: req.body.PositionID
        });
        await empDeptPos.save();

        // 3. Get Department Name
        let dept = await Department.findById(req.body.DepartmentID).exec();
        let DeptName = dept && dept.DepartmentName ? dept.DepartmentName : '';
        DeptName = DeptName.substring(0, Math.min(3, DeptName.length)).toUpperCase();

        // 4. Generate Username
        let firstNamePart = (employee.FirstName || '').substring(0, 4).toUpperCase();
        let Username = DeptName + firstNamePart + employee._id.toString().slice(-4);

        // 5. Generate Password
        let Password = generatePassword();

        // 6. Create EmpCred
        const empCred = new EmpCred({
            EmpID: employee._id,
            UserName: Username,
            Password: Password
        });
        await empCred.save();

        res.status(201).json({
            employee,
            empDeptPos,
            empCred,
            Username,
            Password
        });
    } catch (err) {
        next(err);
    }
};

exports.GetEmployee = (req, res, next) => {
    try{
        const employee = Employee.find();
        res.status(200).json(employee);
    }catch(err){
        next(err);  
    }
};

exports.UpdateEmployee = (req, res, next) => {
    try{
        const employee = Employee.findByIdAndUpdate(req.params.id, req.body);
        res.status(200).json(employee);
    }catch(err){
        next(err);  
    }
};

exports.DeleteEmployee = (req, res, next) => {
    try{
        const employee = Employee.findByIdAndDelete(req.params.id);
        res.status(200).json(employee);
    }catch(err){
        next(err);  
    }
};
