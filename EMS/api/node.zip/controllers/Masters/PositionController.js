const Position = require('../../models/PositionModel');

// Get all positions
exports.getPositions = async (req, res) => {
    try {
        const positions = await Position.find();
        res.json(positions);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Get position by ID
exports.getPosition = async (req, res) => {
    try {
        const position = await Position.findById(req.params.id);
        if (!position) return res.status(404).json({ message: 'Position not found' });
        res.json(position);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Create a new position
exports.createPosition = async (req, res) => {
    const position = new Position(req.body);
    try {
        const newPosition = await position.save();
        res.status(201).json(newPosition);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

// Update a position
exports.updatePosition = async (req, res) => {
    try {
        const updatedPosition = await Position.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!updatedPosition) return res.status(404).json({ message: 'Position not found' });
        res.status(204).end();
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

// Delete a position
exports.deletePosition = async (req, res) => {
    try {
        const position = await Position.findByIdAndDelete(req.params.id);
        if (!position) return res.status(404).json({ message: 'Position not found' });
        res.status(204).end();
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};