const Department = require('../../models/DepartmentModel');

// Get all departments
exports.GetDepartments = async (req, res, next) => {
    try {
        const departments = await Department.find();
        res.status(200).json(departments);
    } catch (err) {
        next(err);
    }
};

// Get a department by ID
exports.GetDepartment = async (req, res, next) => {
    try {
        const department = await Department.findById(req.params.id);
        if (!department) {
            return res.status(404).json({ message: 'Department not found.' });
        }
        res.status(200).json(department);
    } catch (err) {
        next(err);
    }
};

// Create a new department
exports.CreateDepartment = async (req, res, next) => {
    try {
        if (!req.body || !req.body.deptName) {
            return res.status(400).json({ message: 'DepartmentName is required.' });
        }
        const department = new Department({
            deptName: req.body.deptName
        });
        await department.save();
        res.status(201).json(department);
    } catch (err) {
        next(err);
    }
};

// Update a department by ID
exports.UpdateDepartment = async (req, res, next) => {
    try {
        const department = await Department.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!department) {
            return res.status(404).json({ message: 'Department not found.' });
        }
        res.status(200).json(department);
    } catch (err) {
        next(err);
    }
};

// Delete a department by ID
exports.DeleteDepartment = async (req, res, next) => {
    try {
        const department = await Department.findByIdAndDelete(req.params.id);
        if (!department) {
            return res.status(404).json({ message: 'Department not found.' });
        }
        res.status(204).send();
    } catch (err) {
        next(err);
    }
};
