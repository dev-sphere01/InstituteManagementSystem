const mongoose = require('mongoose');
const dotenv = require('dotenv');
const getBaseConfig = require('../utils/getBaseConfig');

dotenv.config();

const connectDB = async () => {
  const { dbURI, stage } = getBaseConfig();

  try {
    const conn = await mongoose.connect(dbURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log(`✅ [${stage.toUpperCase()}] MongoDB Connected: ${conn.connection.host}`);
  } catch (err) {
    console.error(`❌ MongoDB connection error: ${err.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
