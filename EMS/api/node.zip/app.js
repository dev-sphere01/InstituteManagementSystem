const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const bodyParser = require('body-parser');

const { notFound, errorHandler } = require('./middleware/error.middleware');

//routes
const routes = require('./routes/index.js');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(morgan('dev'));
app.use(express.static('wwwroot'));

app.use(cors({
  origin: process.env.ALLOWED_HOSTS,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Routes
app.use('/api', routes);

// Error Handlers
app.use(notFound);
app.use(errorHandler);

module.exports = app;
