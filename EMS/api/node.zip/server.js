const http = require('http');
const dotenv = require('dotenv');
const app = require('./app');
const connectDB = require('./config/connectDB');
const getBaseConfig = require('./utils/getBaseConfig');

dotenv.config();

const { stage, domain, port, dbURI } = getBaseConfig();

const server = http.createServer(app);

// Connect to DB and start server
connectDB(dbURI).then(() => {
  server.listen(port, () => {
    console.log(`🚀 Server is running at http://${domain}:${port} (${stage.toUpperCase()} mode)`);
  });
});
