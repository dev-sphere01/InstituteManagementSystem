// utils/getBaseConfig.js

const dotenv = require('dotenv');
dotenv.config();

const getBaseConfig = () => {
  const stage = process.env.STAGE || 'development';

  const config = {
    stage,
    domain: stage === 'development' ? process.env.DOMAIN_LOCAL : process.env.DOMAIN_LIVE,
    port: stage === 'development' ? process.env.PORT_LOCAL : process.env.PORT_LIVE,
    dbURI: stage === 'development' ? process.env.DB_URI_LOCAL : process.env.DB_URI_LIVE
  };

  return config;
};

module.exports = getBaseConfig;
