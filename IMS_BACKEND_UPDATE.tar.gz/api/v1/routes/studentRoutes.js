const express = require('express');
const router = express.Router();
const { isAuthenticatedUser } = require('../../../middlewares/auth');
const { requireModulePermission } = require('../../../middlewares/permission');
const { getAllStudents, getStudentProfile, updateDocumentStatus, updateStudentProfile } = require('./../../../controllers/studentController');

router.use(isAuthenticatedUser);

router.get('/', requireModulePermission('student', 'view'), getAllStudents);
router.get('/:id', requireModulePermission('student', 'view'), getStudentProfile);
router.put('/:id', requireModulePermission('student', 'edit'), updateStudentProfile);
router.put('/:id/documents', requireModulePermission('student', 'edit'), updateDocumentStatus);


module.exports = router;
