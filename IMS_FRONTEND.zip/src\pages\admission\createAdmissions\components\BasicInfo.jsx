import React, { useState, useEffect } from 'react';
import { useThemeStore } from '../../../../store';
import { useNotification } from '../../../../services/NotificationService';
import API from '../../../../services/API';
import { useAuth } from '../../../../context/AuthContext';
import DatePicker from '../../../../components/common/DatePicker';

const BasicInfo = ({ formData = {}, setFormData = () => { }, onNext, validationsEnabled }) => {
  const notify = useNotification();
  const { isDarkMode } = useThemeStore();
  const { user } = useAuth();


  const [form, setForm] = useState({
    formNo: '',
    centerCode: '',
    employeeId: '',
    generatedRegNo: '',
    fullName: '',
    dob: '',
    gender: '',
    category: '',
    aadharNo: '',
    religion: '',
    otherInfo: '',
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [centres, setCentres] = useState([]);
  const [centreDropdownOpen, setCentreDropdownOpen] = useState(false);
  const [centreSearch, setCentreSearch] = useState('');


  useEffect(() => {
    const formattedDob = formData.dob ? formData.dob.substring(0, 10) : '';
    const monthsList = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const currentMonthName = formData.month || monthsList[new Date().getMonth()];
    setForm({
      ...formData,
      dob: formattedDob,
      month: currentMonthName,
      employeeId: user?._id || '', // inject employee ID here
    });
  }, [formData, user]);


  const fetchAllCentres = async () => {
    try {
      const response = await API.get('/centre-codes');
      setCentres(response?.data || []);
    } catch (error) {
      console.error('Error fetching centres:', error);
    }
  };

  useEffect(() => {
    fetchAllCentres();
    console.log(centres);
  }, []);

  useEffect(() => {
    const fetchNextIdentifiers = async () => {
      if (!form.centerCode) {
        setForm(prev => ({ ...prev, formNo: '', generatedRegNo: '' }));
        return;
      }

      // If already populated and matches current centerCode, don't fetch/overwrite
      const shouldFetchFormNo = !(formData && formData.formNo && formData.centerCode === form.centerCode);
      const shouldFetchRegNo = !(formData && formData.generatedRegNo && formData.centerCode === form.centerCode);

      try {
        if (shouldFetchFormNo) {
          const response = await API.get(`/admissions/next-form-no/${form.centerCode}`);
          if (response && response.success) {
            setForm(prev => ({ ...prev, formNo: response.nextFormNo }));
            if (errors.formNo) {
              setErrors(prev => ({ ...prev, formNo: '' }));
            }
          }
        }

        if (shouldFetchRegNo) {
          const response = await API.get(`/admissions/next-reg-no/${form.centerCode}`);
          if (response && response.success) {
            setForm(prev => ({ ...prev, generatedRegNo: response.nextRegNo }));
            if (errors.generatedRegNo) {
              setErrors(prev => ({ ...prev, generatedRegNo: '' }));
            }
          }
        }
      } catch (error) {
        console.error('Error fetching identifiers:', error);
        notify('Failed to generate form or registration number.', 'error');
      }
    };

    fetchNextIdentifiers();
  }, [form.centerCode, formData]);

  const filteredCentres = centres.filter(c =>
    c.centreCode.toLowerCase().includes(centreSearch.toLowerCase())
  );

  const handleCentreSelect = (centre) => {
    setForm(prev => ({ ...prev, centerCode: centre.centreCode }));
    setCentreSearch('');
    setCentreDropdownOpen(false);
    if (errors.centerCode) {
      setErrors(prev => ({ ...prev, centerCode: '' }));
    }
  };


  const requiredFields = [
    'formNo', 'centerCode', 'employeeId', 'generatedRegNo',
    'fullName', 'dob', 'gender', 'category', 'aadharNo', 'religion',
  ];

  const validate = () => {
    if (!validationsEnabled) {
      setErrors({});
      return true;
    }

    const errs = {};
    requiredFields.forEach((field) => {
      if (!form[field]?.toString().trim()) errs[field] = 'This field is required';
    });

    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      notify('Please fill all required fields.', 'error');
    }
    return Object.keys(errs).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      if (typeof onNext === 'function') {
        onNext(form);
        notify('Basic information saved successfully.', 'success');
      }
    } catch (err) {
      console.error('Failed to proceed:', err);
      notify('Failed to proceed to next step.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputStyle = (field) =>
    `block w-full px-4 py-2 border rounded-lg shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors[field]
      ? 'border-red-500 focus:ring-red-400'
      : isDarkMode
        ? 'border-gray-600 bg-gray-700 text-white placeholder-gray-400'
        : 'border-gray-300 bg-gray-50 text-gray-900 placeholder-gray-400'
    }`;

  const labelStyle = `block text-sm font-semibold mb-2 tracking-wide ${isDarkMode ? 'text-gray-200' : 'text-gray-800'
    }`;

  return (
    <div
      className={`rounded-2xl shadow-lg mt-8 p-8 w-full mx-auto ${isDarkMode
        ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border border-gray-700'
        : 'bg-gradient-to-br from-white via-gray-50 to-blue-50 border border-gray-200'
        }`}
    >
      <h2 className={`text-2xl font-bold mb-8 tracking-tight ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>
        Step 1: Basic Info
      </h2>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {/* Center Code - Searchable Dropdown */}
          <div className="relative">
            <label className={labelStyle}>
              Center Code {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              value={centreDropdownOpen ? centreSearch : form.centerCode}
              onChange={(e) => setCentreSearch(e.target.value)}
              onFocus={() => setCentreDropdownOpen(true)}
              onBlur={() => setTimeout(() => setCentreDropdownOpen(false), 200)}
              placeholder="Search and select center code"
              className={inputStyle('centerCode')}
            />
            {centreDropdownOpen && (
              <div className="absolute z-50 w-full mt-1 max-h-60 overflow-y-auto border rounded-lg shadow-lg bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600">
                {filteredCentres.length > 0 ? (
                  filteredCentres.map((centre, index) => (
                    <div
                      key={index}
                      className="px-4 py-2 cursor-pointer hover:bg-blue-100 dark:hover:bg-gray-700 text-sm"
                      onMouseDown={() => handleCentreSelect(centre)}
                    >
                      {centre.centreCode}
                    </div>
                  ))
                ) : (
                  <div className="px-4 py-2 text-gray-500 dark:text-gray-400">No center found</div>
                )}
              </div>
            )}
            {errors.centerCode && <p className="text-xs text-red-400 mt-1">{errors.centerCode}</p>}
          </div>

          {/* Form No */}
          <div>
            <label className={labelStyle}>
              Form No {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              name="formNo"
              value={form.formNo || ''}
              readOnly
              placeholder={form.centerCode ? "Generating..." : "Please select Center Code first"}
              className={`${inputStyle('formNo')} bg-gray-100 dark:bg-gray-800 cursor-not-allowed`}
              autoComplete="off"
            />
            {errors.formNo && <p className="text-xs text-red-400 mt-1">{errors.formNo}</p>}
          </div>

          {/* Employee ID */}
          <div>
            <label className={labelStyle}>
              Employee ID {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              name="employeeId"
              value={form.employeeId || ''}
              readOnly // make it non-editable
              disabled // optional: greyed-out and not focusable
              className={inputStyle('employeeId')}
            />

            {errors.employeeId && <p className="text-xs text-red-400 mt-1">{errors.employeeId}</p>}
          </div>

          {/* Generated Reg No */}
          <div>
            <label className={labelStyle}>
              Generated Reg No {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              name="generatedRegNo"
              value={form.generatedRegNo || ''}
              readOnly
              placeholder={form.centerCode ? "Generating..." : "Please select Center Code first"}
              className={`${inputStyle('generatedRegNo')} bg-gray-100 dark:bg-gray-800 cursor-not-allowed`}
              autoComplete="off"
            />
            {errors.generatedRegNo && <p className="text-xs text-red-400 mt-1">{errors.generatedRegNo}</p>}
          </div>

          {/* Full Name */}
          <div>
            <label className={labelStyle}>
              Full Name {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              name="fullName"
              value={form.fullName || ''}
              onChange={handleChange}
              className={inputStyle('fullName')}
              autoComplete="off"
            />
            {errors.fullName && <p className="text-xs text-red-400 mt-1">{errors.fullName}</p>}
          </div>

          {/* Aadhar No */}
          <div>
            <label className={labelStyle}>
              Aadhar No {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text"
              name="aadharNo"
              value={form.aadharNo || ''}
              onChange={handleChange}
              className={inputStyle('aadharNo')}
              autoComplete="off"
            />
            {errors.aadharNo && <p className="text-xs text-red-400 mt-1">{errors.aadharNo}</p>}
          </div>

          {/* Religion */}
          <div>
            <label className={labelStyle}>
              Religion {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <select
              name="religion"
              value={form.religion || ''}
              onChange={handleChange}
              className={inputStyle('religion')}
            >
              <option value="">Select religion</option>
              <option value="Hindu">Hindu</option>
              <option value="Muslim">Muslim</option>
              <option value="Christian">Christian</option>
              <option value="Sikh">Sikh</option>
              <option value="Buddhist">Buddhist</option>
              <option value="Jain">Jain</option>
              <option value="Other">Other</option>
            </select>
            {errors.religion && <p className="text-xs text-red-400 mt-1">{errors.religion}</p>}
          </div>

          {/* DOB */}
          <div>
            <label className={labelStyle}>
              Date of Birth {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <DatePicker
              value={form.dob || ''}
              onChange={handleChange}
              placeholder="dd-mm-yyyy"
              className={inputStyle('dob')}
              isDarkMode={isDarkMode}
            />
            {errors.dob && <p className="text-xs text-red-400 mt-1">{errors.dob}</p>}
          </div>

          {/* Gender */}
          <div>
            <label className={labelStyle}>
              Gender {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <select
              name="gender"
              value={form.gender}
              onChange={handleChange}
              className={inputStyle('gender')}
            >
              <option value="">Select gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
            {errors.gender && <p className="text-xs text-red-400 mt-1">{errors.gender}</p>}
          </div>

          {/* Category */}
          <div>
            <label className={labelStyle}>
              Category {validationsEnabled && <span className="text-red-500">*</span>}
            </label>
            <select
              name="category"
              value={form.category || ''}
              onChange={handleChange}
              className={inputStyle('category')}
            >
              <option value="">Select category</option>
              <option value="GEN">General (GEN)</option>
              <option value="OBC">Other Backward Class (OBC)</option>
              <option value="SC">Scheduled Caste (SC)</option>
              <option value="ST">Scheduled Tribe (ST)</option>
              <option value="OTHER">Other</option>
            </select>
            {errors.category && <p className="text-xs text-red-400 mt-1">{errors.category}</p>}
          </div>

          {/* Other Info */}
          <div className="md:col-span-2">
            <label className={labelStyle}>Other Info</label>
            <textarea
              name="otherInfo"
              value={form.otherInfo || ''}
              onChange={handleChange}
              placeholder="Optional notes"
              rows={3}
              className={`${inputStyle('otherInfo')} resize-none`}
            />
          </div>
        </div>

        <div className="flex justify-end pt-8 border-t border-gray-200 dark:border-gray-700">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`px-6 py-2 rounded-lg shadow font-semibold text-sm text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${isSubmitting
              ? 'bg-blue-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600'
              }`}
          >
            {isSubmitting ? 'Saving...' : 'Next'}
          </button>
        </div>
      </form>
    </div>
  );

};

export default BasicInfo;
